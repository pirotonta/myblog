<footer class="bg-zinc-950 text-white py-8">
    <div class="text-lg flex justify-center mt-10">
        acá ponemos una descripción xd
    </div>

    <div class="text-center text-sm text-gray-400 mt-6">
        <p>
            temporal
        </p>
    </div>

    <div class="flex justify-center space-x-15 mb-5">
        <div class="flex items-center space-x-1 mt-2">
            <!-- <img class="w-15" src="../../../../images/github-icon.svg" alt="icono-github" /> -->
            <a class="font-semibold "
                href="https://github.com/pirotonta"
                target="_blank">
                pirotonta
            </a>
        </div>
        <div class="flex items-center space-x-1 mt-2">
            <!-- <img class="w-15" src="../../../../images/github-icon.svg" alt="icono-github" /> -->
            <a class="font-semibold "
                href="https://github.com/MorenoGise"
                target="_blank">
                MorenoGise
            </a>
        </div>
    </div>
</footer>