@extends('layouts.app')

@section('content')
    <h1>Posts in "{{ $category->name }}"</h1>
    <a href="{{ url('/posts') }}">← Back to all posts</a>

    @forelse ($posts as $post)
        <div style="margin-top: 20px;">
            <h2><a href="{{ url('/posts/' . $post->id) }}">{{ $post->title }}</a></h2>
            <p>{{ Str::limit($post->content, 150) }}</p>
            <p><small>By: {{ $post->user->name }}</small></p>
        </div>
    @empty
        <p>No posts in this category yet.</p>
    @endforelse
@endsection